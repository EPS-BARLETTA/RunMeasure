// Place ton script existant ici. UI harmonisée via styles.css
